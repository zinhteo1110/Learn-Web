<html> 
 <head> 
  <link href="../../css/phpMM.css" rel="stylesheet" type="text/css" /> 
 </head> 
 
 <body> 
  <div id="header"><h1>PHP & MySQL: The Missing Manual</h1></div> 
  <div id="example">Example 1-1</div> 
 
  <div id="content"> 
    <h1>Hello, <?php echo $_REQUEST['name']; ?></h1> 
    <p>Great to meet you. Welcome to the beginning of your PHP programming odyssey.</p> 
    </form> 
  </div> 
 
  <div id="footer"></div> 
 </body> 
</html>
