<?php

echo $message;

?>
