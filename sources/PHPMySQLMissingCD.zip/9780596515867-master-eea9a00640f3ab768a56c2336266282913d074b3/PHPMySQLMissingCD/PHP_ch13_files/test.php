<?php

$message = "hello\n\n";

require_once "print.php";
?>
