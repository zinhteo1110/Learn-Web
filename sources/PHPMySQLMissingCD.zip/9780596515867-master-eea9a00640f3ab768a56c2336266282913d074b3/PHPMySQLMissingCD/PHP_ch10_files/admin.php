<html>
 <head>
  <link href="../css/phpMM.css" rel="stylesheet" type="text/css" />
 </head>

 <body>
  <div id="header"><h1>PHP & MySQL: The Missing Manual</h1></div>
  <div id="example">Current Users</div>

  <div id="content">
   <ul>
    <li>
     <a href="show_user.php?user_id=30">William Shatner</a>
     (<a href="mailto:bill@williamshatner.com">bill@williamshatner.com</a>)
     <a href="delete_user.php?user_id=30">
       <img class="delete_user" src="../images/delete.png" width="15" />
     </a>
    </li>
    <li>
     <a href="show_user.php?user_id=22">James Roday</a>
     (<a href="mailto:james@roday.net">james@roday.net</a>)
     <a href="delete_user.php?user_id=22">
       <img class="delete_user" src="../images/delete.png" width="15" />
     </a>
    </li>
    <li>
     <a href="show_user.php?user_id=1">C. J. Wilson</a>
     (<a href="mailto:cj@texasrangers.com">cj@texasrangers.com</a>)
     <a href="delete_user.php?user_id=1">
       <img class="delete_user" src="../images/delete.png" width="15" />
     </a>
    </li>
   </ul>
  </div>
  <div id="footer"></div>
 </body>
</html>
